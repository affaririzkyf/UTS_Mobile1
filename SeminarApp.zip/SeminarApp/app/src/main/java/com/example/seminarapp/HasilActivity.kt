package com.example.seminarapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.seminarapp.databinding.ActivityHasilBinding

class HasilActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHasilBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHasilBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val nama         = intent.getStringExtra("NAMA") ?: "-"
        val email        = intent.getStringExtra("EMAIL") ?: "-"
        val noHp         = intent.getStringExtra("NO_HP") ?: "-"
        val jenisKelamin = intent.getStringExtra("JENIS_KELAMIN") ?: "-"
        val seminar      = intent.getStringExtra("SEMINAR") ?: "-"

        binding.tvNama.text         = nama
        binding.tvEmail.text        = email
        binding.tvNoHp.text         = noHp
        binding.tvJenisKelamin.text = jenisKelamin
        binding.tvSeminar.text      = seminar

        binding.btnKembaliHome.setOnClickListener {
            // Kembali ke HomeActivity, hapus stack form & hasil
            val intent = Intent(this, HomeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish()
        }
    }
}
