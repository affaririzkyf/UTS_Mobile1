package com.example.seminarapp

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.seminarapp.databinding.ActivityFormPendaftaranBinding

class FormPendaftaranActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFormPendaftaranBinding

    companion object {
        private const val TAG = "FormPendaftaran"

        // Data seminar hardcode (minimal 5 sesuai soal)
        val DAFTAR_SEMINAR = listOf(
            "-- Pilih Seminar --",
            "Seminar Nasional Kecerdasan Buatan 2025",
            "Workshop Pengembangan Aplikasi Mobile",
            "Seminar Keamanan Siber & Etika Digital",
            "Seminar Wirausaha Muda Teknologi",
            "Seminar Internet of Things (IoT) Terapan",
            "Workshop UI/UX Design Thinking",
            "Seminar Big Data & Cloud Computing"
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFormPendaftaranBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Log.d(TAG, "onCreate() called")

        // Isi nama & email dari data login jika ada
        val userName = intent.getStringExtra("USER_NAME") ?: ""
        val userEmail = intent.getStringExtra("USER_EMAIL") ?: ""
        if (userName.isNotEmpty()) binding.etNama.setText(userName)
        if (userEmail.isNotEmpty()) binding.etEmail.setText(userEmail)

        setupSpinner()
        setupRealTimeValidation()
        setupButtons()
    }

    // ============================================================
    // setupSpinner – isi data seminar ke Spinner
    // ============================================================
    private fun setupSpinner() {
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            DAFTAR_SEMINAR
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerSeminar.adapter = adapter
        Log.d(TAG, "setupSpinner() done (${DAFTAR_SEMINAR.size} items)")
    }

    // ============================================================
    // setupRealTimeValidation – validasi langsung saat mengetik
    // ============================================================
    private fun setupRealTimeValidation() {

        // Real-time: Nama
        binding.etNama.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val v = s?.toString()?.trim() ?: ""
                binding.tilNama.error = when {
                    v.isEmpty() -> null
                    v.length < 3 -> "Nama minimal 3 karakter"
                    else -> null
                }
            }
        })

        // Real-time: Email (harus mengandung "@")
        binding.etEmail.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val v = s?.toString()?.trim() ?: ""
                binding.tilEmail.error = when {
                    v.isEmpty() -> null
                    !v.contains("@") -> "Email harus mengandung '@'"
                    else -> null
                }
            }
        })

        // Real-time: Nomor HP (hanya angka, 10-13 digit, diawali 08)
        binding.etNoHp.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val v = s?.toString()?.trim() ?: ""
                binding.tilNoHp.error = validateNoHp(v, realTime = true)
            }
        })
    }

    // ============================================================
    // validateNoHp – validasi khusus Nomor HP
    //   realTime=true  → tidak tampilkan error saat masih mengetik
    //   realTime=false → tampilkan semua error saat submit
    // ============================================================
    private fun validateNoHp(value: String, realTime: Boolean): String? {
        if (value.isEmpty()) return if (realTime) null else "Nomor HP tidak boleh kosong"
        if (!value.all { it.isDigit() }) return "Nomor HP hanya boleh berisi angka"
        if (!value.startsWith("08")) return "Nomor HP harus diawali dengan 08"
        if (value.length < 10) return if (realTime) null else "Nomor HP minimal 10 digit"
        if (value.length > 13) return "Nomor HP maksimal 13 digit"
        return null
    }

    private fun setupButtons() {
        binding.btnSubmit.setOnClickListener {
            Log.d(TAG, "btnSubmit clicked")
            if (validateForm()) {
                showConfirmationDialog()
            }
        }

        binding.btnBatal.setOnClickListener {
            finish()
        }
    }

    // ============================================================
    // validateForm – validasi semua field saat tombol Submit ditekan
    // ============================================================
    private fun validateForm(): Boolean {
        var isValid = true

        // Validasi Nama
        val nama = binding.etNama.text?.toString()?.trim() ?: ""
        if (nama.isEmpty()) {
            binding.tilNama.error = "Nama tidak boleh kosong"
            isValid = false
        } else if (nama.length < 3) {
            binding.tilNama.error = "Nama minimal 3 karakter"
            isValid = false
        } else {
            binding.tilNama.error = null
        }

        // Validasi Email
        val email = binding.etEmail.text?.toString()?.trim() ?: ""
        if (email.isEmpty()) {
            binding.tilEmail.error = "Email tidak boleh kosong"
            isValid = false
        } else if (!email.contains("@")) {
            binding.tilEmail.error = "Email harus mengandung '@'"
            isValid = false
        } else {
            binding.tilEmail.error = null
        }

        // Validasi Nomor HP
        val noHp = binding.etNoHp.text?.toString()?.trim() ?: ""
        val hpError = validateNoHp(noHp, realTime = false)
        if (hpError != null) {
            binding.tilNoHp.error = hpError
            isValid = false
        } else {
            binding.tilNoHp.error = null
        }

        // Validasi Jenis Kelamin
        if (binding.rgJenisKelamin.checkedRadioButtonId == -1) {
            Toast.makeText(this, "Pilih jenis kelamin terlebih dahulu", Toast.LENGTH_SHORT).show()
            isValid = false
        }

        // Validasi Spinner Seminar
        if (binding.spinnerSeminar.selectedItemPosition == 0) {
            Toast.makeText(this, "Pilih seminar terlebih dahulu", Toast.LENGTH_SHORT).show()
            isValid = false
        }

        // Validasi Checkbox Persetujuan
        if (!binding.cbSetuju.isChecked) {
            Toast.makeText(this, "Anda harus menyetujui pernyataan di atas", Toast.LENGTH_SHORT).show()
            isValid = false
        }

        Log.d(TAG, "validateForm() result = $isValid")
        return isValid
    }

    // ============================================================
    // showConfirmationDialog – dialog konfirmasi sebelum submit
    // ============================================================
    private fun showConfirmationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Konfirmasi Pendaftaran")
            .setMessage("Apakah data yang Anda isi sudah benar?")
            .setPositiveButton("Ya") { _, _ ->
                Log.d(TAG, "Dialog: Ya → ke HasilActivity")
                goToHasil()
            }
            .setNegativeButton("Tidak") { dialog, _ ->
                Log.d(TAG, "Dialog: Tidak → tetap di form")
                dialog.dismiss()
            }
            .show()
    }

    private fun goToHasil() {
        val nama       = binding.etNama.text?.toString()?.trim() ?: ""
        val email      = binding.etEmail.text?.toString()?.trim() ?: ""
        val noHp       = binding.etNoHp.text?.toString()?.trim() ?: ""
        val jenisKelamin = when (binding.rgJenisKelamin.checkedRadioButtonId) {
            R.id.rbLakiLaki -> "Laki-laki"
            R.id.rbPerempuan -> "Perempuan"
            else -> "-"
        }
        val seminar = binding.spinnerSeminar.selectedItem?.toString() ?: "-"

        val intent = Intent(this, HasilActivity::class.java).apply {
            putExtra("NAMA", nama)
            putExtra("EMAIL", email)
            putExtra("NO_HP", noHp)
            putExtra("JENIS_KELAMIN", jenisKelamin)
            putExtra("SEMINAR", seminar)
        }
        startActivity(intent)
    }
}
