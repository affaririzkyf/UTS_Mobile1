package com.example.seminarapp

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.seminarapp.databinding.ActivityRegisterBinding

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRealTimeValidation()
        setupButtons()
    }

    private fun setupRealTimeValidation() {
        binding.etNama.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val v = s?.toString()?.trim() ?: ""
                binding.tilNama.error = if (v.isNotEmpty() && v.length < 3) "Nama minimal 3 karakter" else null
            }
        })

        binding.etEmail.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val v = s?.toString()?.trim() ?: ""
                binding.tilEmail.error = if (v.isNotEmpty() && !v.contains("@")) "Email harus mengandung '@'" else null
            }
        })

        binding.etPassword.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val v = s?.toString() ?: ""
                binding.tilPassword.error = if (v.isNotEmpty() && v.length < 6) "Password minimal 6 karakter" else null
            }
        })
    }

    private fun setupButtons() {
        binding.btnRegister.setOnClickListener {
            if (validateRegister()) {
                Toast.makeText(this, "Registrasi berhasil! Silakan login.", Toast.LENGTH_LONG).show()
                finish()
            }
        }

        binding.btnKeLogin.setOnClickListener { finish() }
    }

    private fun validateRegister(): Boolean {
        val nama = binding.etNama.text?.toString()?.trim() ?: ""
        val email = binding.etEmail.text?.toString()?.trim() ?: ""
        val password = binding.etPassword.text?.toString() ?: ""
        var isValid = true

        if (nama.isEmpty()) { binding.tilNama.error = "Nama tidak boleh kosong"; isValid = false }
        else if (nama.length < 3) { binding.tilNama.error = "Nama minimal 3 karakter"; isValid = false }
        else binding.tilNama.error = null

        if (email.isEmpty()) { binding.tilEmail.error = "Email tidak boleh kosong"; isValid = false }
        else if (!email.contains("@")) { binding.tilEmail.error = "Email harus mengandung '@'"; isValid = false }
        else binding.tilEmail.error = null

        if (password.isEmpty()) { binding.tilPassword.error = "Password tidak boleh kosong"; isValid = false }
        else if (password.length < 6) { binding.tilPassword.error = "Password minimal 6 karakter"; isValid = false }
        else binding.tilPassword.error = null

        return isValid
    }
}
