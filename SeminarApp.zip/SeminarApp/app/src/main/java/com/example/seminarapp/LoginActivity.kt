package com.example.seminarapp

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.seminarapp.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    companion object {
        private const val TAG = "LoginActivity"

        // Data user hardcode (sesuai ketentuan soal)
        private val VALID_USERS = mapOf(
            "admin@seminar.com" to "admin123",
            "mahasiswa@gmail.com" to "mahasiswa",
            "user@test.com" to "password"
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Log.d(TAG, "onCreate() called")

        setupRealTimeValidation()
        setupButtons()
    }

    private fun setupRealTimeValidation() {
        // Real-time validasi Email
        binding.etEmail.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val email = s?.toString()?.trim() ?: ""
                binding.tilEmail.error = when {
                    email.isEmpty() -> null
                    !email.contains("@") -> "Email harus mengandung '@'"
                    else -> null
                }
            }
        })

        // Real-time validasi Password
        binding.etPassword.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val pw = s?.toString() ?: ""
                binding.tilPassword.error = when {
                    pw.isEmpty() -> null
                    pw.length < 6 -> "Password minimal 6 karakter"
                    else -> null
                }
            }
        })
    }

    private fun setupButtons() {
        binding.btnLogin.setOnClickListener {
            Log.d(TAG, "btnLogin clicked")
            if (validateLogin()) {
                val email = binding.etEmail.text?.toString()?.trim() ?: ""
                val intent = Intent(this, HomeActivity::class.java)
                intent.putExtra("USER_EMAIL", email)
                // Ambil nama dari email (sebelum @)
                val namaUser = email.substringBefore("@").replaceFirstChar { it.uppercase() }
                intent.putExtra("USER_NAME", namaUser)
                startActivity(intent)
                finish()
            }
        }

        binding.btnKeRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun validateLogin(): Boolean {
        val email = binding.etEmail.text?.toString()?.trim() ?: ""
        val password = binding.etPassword.text?.toString() ?: ""
        var isValid = true

        if (email.isEmpty()) {
            binding.tilEmail.error = "Email tidak boleh kosong"
            isValid = false
        } else if (!email.contains("@")) {
            binding.tilEmail.error = "Email harus mengandung '@'"
            isValid = false
        } else {
            binding.tilEmail.error = null
        }

        if (password.isEmpty()) {
            binding.tilPassword.error = "Password tidak boleh kosong"
            isValid = false
        } else if (password.length < 6) {
            binding.tilPassword.error = "Password minimal 6 karakter"
            isValid = false
        } else {
            binding.tilPassword.error = null
        }

        if (!isValid) return false

        // Cek kredensial
        val expectedPassword = VALID_USERS[email]
        if (expectedPassword == null || expectedPassword != password) {
            Toast.makeText(this, "Email atau password salah!", Toast.LENGTH_SHORT).show()
            Log.d(TAG, "Login gagal: email=$email")
            return false
        }

        Log.d(TAG, "Login berhasil: $email")
        return true
    }
}
